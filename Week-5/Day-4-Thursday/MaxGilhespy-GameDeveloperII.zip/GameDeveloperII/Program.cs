﻿// Max Gilhespy

using System.Runtime.CompilerServices;
using GameDeveloperII.Classes;

public class Program
{
    public static void Main()
    {
        System.Console.WriteLine();
        System.Console.WriteLine("Enemies fighting this round:");

        // create instances of each subclass
        MeleeFighter meleeFighter = new("Wrestler");
        RangedFighter rangedFighter = new("Archer");
        MagicCaster magicCaster = new("Sorcerer");

        System.Console.WriteLine();

        // to see the health attack and attack damage of melee fighter
        Console.Write($"Melee Fighter: ");
        meleeFighter.PrintEnemyStats();

        System.Console.WriteLine();

        // to see the health attack and attack damage of ranged fighter
        Console.Write($"Ranged Fighter: ");
        rangedFighter.PrintEnemyStats();

        System.Console.WriteLine();

        // to see the health attack and attack damage of magic caster
        Console.Write($"Magic Caster: ");
        magicCaster.PrintEnemyStats();

        System.Console.WriteLine();
        System.Console.WriteLine("Let the fight begin!");
        System.Console.WriteLine();

        // Perform the Kick attack
        // Attack has been made nullable with ?
        // uses a linq method (FirstOrDefault) with a lambda expression (a => a.Name == "Kick")
        // to look for the Kick attack in AttackList and then assigns attack name and damage amount
        // to kickAttack
        Attack? kickAttack = meleeFighter.AttackList.FirstOrDefault(a => a.Name == "Kick");

        // calls PerformAttack on the MeleeFighter object, passing in rangedFighter and kickAttack.
        meleeFighter.PerformAttack(rangedFighter, kickAttack);

        // calls Rage on the MeleeFighter object, passing in magicCaster
        meleeFighter.Rage(magicCaster);

        // using the linq method with the lambda expression again
        Attack? shootArrow = rangedFighter.AttackList.FirstOrDefault(a => a.Name == "Shoot Arrow");

        // calls RangedFighterAttack on the RangedFighter class passing in meleeFighter and shootArroe 
        rangedFighter.RangedFighterAttack(meleeFighter, shootArrow);

        // calls Dash on the RangedFighter class
        rangedFighter.Dash();

        // calls RangedFighterAttack again
        rangedFighter.RangedFighterAttack(meleeFighter, shootArrow);

        // using the linq method with the lambda expression again
        Attack? fireball = magicCaster.AttackList.FirstOrDefault(a => a.Name == "Fireball");

        magicCaster.PerformAttack(meleeFighter, fireball);

        magicCaster.Heal(rangedFighter);

        magicCaster.Heal(magicCaster);

        System.Console.WriteLine();
    }
}

