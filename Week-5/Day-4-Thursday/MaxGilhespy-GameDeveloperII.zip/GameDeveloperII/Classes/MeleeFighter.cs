// Max Gilhespy

namespace GameDeveloperII.Classes;

public class MeleeFighter : Enemy
{
    public MeleeFighter(string name) : base(name, 120)
    {
        // initialze the name of the melee fighter using the argument passed in
        Name = name;
        // add the melee fighter's attacks to the AttackList in Enemy class
        AddAttacks(
            new Attack("Punch", 20),
            new Attack("Kick", 15),
            new Attack("Tackle", 25)
        );
    }

    public void MeleeFighterAttack(Enemy Target)
    {

    }

    public void Rage(Enemy Target)
    {
        /* 
           The fighter performs a random attack from its AttackList, but the attack deals 
           10 extra damage Hint: How will you handle updating the DamageAmount of your attack 
           when you perform the attack?
        */

        var randomChosen = RandomAttack();

        // Console.WriteLine($"The attack is {randomChosen}");

        // checks if randomChosen is not null, meaning a random attack was chosen
        if (randomChosen != null)
        {
            randomChosen.DamageAmount += 10;
            // Console.WriteLine($"Now the attack is {randomChosen}");

            // perform the attack on the target
            PerformAttack(Target, randomChosen);
        }
        else
        {
            // this happens if no attack was chosen
            Console.WriteLine("No attack was chosen.");
        }
    }
}