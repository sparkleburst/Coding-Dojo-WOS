// Max Gilhespy

namespace GameDeveloperII.Classes;

public class MagicCaster : Enemy
{
    public MagicCaster(string name) : base(name, 80)
    {
        // initialze the name of the melee fighter using the argument passed in
        Name = name;
        // add the melee fighter's attacks to the AttackList in Enemy class
        AddAttacks(
            new Attack("Fireball", 25),
            new Attack("Lightning Bolt", 20),
            new Attack("Staff Strike", 10)
        );
    }

    public void Heal(Enemy Target)
    {
        int newHealth = Target.GetHealth() + 40;
        Target.SetHealth(newHealth);

        Console.Write($"{Name} casts Heal on {Target.Name} and increases their health to ");

        if (Target.Health >= 100)
        {
            Console.Write($"the maximum: 100\n");
        }

        else
        {
            Console.WriteLine($": {Target.Health}\n");
        }

    }
}
