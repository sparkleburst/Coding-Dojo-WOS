function addingLikes(id) {
    const span = document.getElementById(id);
    span.textContent++;
}