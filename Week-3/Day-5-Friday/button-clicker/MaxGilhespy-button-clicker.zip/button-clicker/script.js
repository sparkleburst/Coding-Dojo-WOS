function hide(element) {
    element.remove();
}

function changeText(element) {
    element.textContent = 'Logout';
}

function alertLikes(element) {
    alert("Ninja was liked");
}